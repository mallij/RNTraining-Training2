/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './src/App';
import FirstScreen from './src/FirstScreen';
import FirstScreenClass from './src/FirstScreenClass';
import SecondScreen from './src/SecondScreen';
import StateManagement from './src/StateManagement';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => StateManagement);
