import React from "react";
import { 
    View, 
    SafeAreaView,
    ScrollView, FlatList, SectionList } from 'react-native';

import firstScreenStyles from './styles/globalStyles';
import MyAppLabel from './components/MyAppLabel';

const SecondScreen = () => {
    // const DATA = [
    //     {
    //       id: '10',
    //       title: 'First Item',
    //     },
    //     {
    //       id: '20',
    //       title: 'Second Item',
    //     },
    //     {
    //       id: '87',
    //       title: 'Third Item',
    //     },
    //     {
    //         id: '10',
    //         title: 'First Item',
    //       },
    //       {
    //         id: '20',
    //         title: 'Second Item',
    //       },
    //       {
    //         id: '87',
    //         title: 'Third Item',
    //       },
    //       {
    //         id: '10',
    //         title: 'First Item',
    //       },
    //       {
    //         id: '20',
    //         title: 'Second Item',
    //       },
    //       {
    //         id: '87',
    //         title: 'Third Item',
    //       },
    //       {
    //         id: '10',
    //         title: 'First Item',
    //       },
    //       {
    //         id: '20',
    //         title: 'Second Item',
    //       },
    //       {
    //         id: '87',
    //         title: 'Third Item',
    //       },
    //       {
    //         id: '10',
    //         title: 'First Item',
    //       },
    //       {
    //         id: '20',
    //         title: 'Second Item',
    //       },
    //       {
    //         id: '87',
    //         title: 'Third Item',
    //       },
    //       {
    //         id: '10',
    //         title: 'First Item',
    //       },
    //       {
    //         id: '20',
    //         title: 'Second Item',
    //       },
    //       {
    //         id: '87',
    //         title: 'Third Item',
    //       },
    //   ];

    const DATA = [
        {
          title: 'Main dishes',
          data: ['Pizza', 'Burger', 'Risotto'],
        },
        {
          title: 'Sides',
          data: ['French Fries', 'Onion Rings', 'Fried Shrimps'],
        },
        {
          title: 'Drinks',
          data: ['Water', 'Coke', 'Beer'],
        },
        {
          title: 'Desserts',
          data: ['Cheese Cake', 'Ice Cream'],
        },
      ];

    // const constructItem = ({item}) => {
    //     return(
    //         <View style={{ flexDirection: 'row', backgroundColor: '#005566', marginVertical: 2}}>
    //             <MyAppLabel labelText={item.title} labelStyle={firstScreenStyles.titleStyle}/>
    //             <MyAppLabel labelText={" - "} labelStyle={firstScreenStyles.titleStyle}/>
    //             <MyAppLabel labelText={item.id} labelStyle={firstScreenStyles.titleStyle}/>
    //         </View>
    //     );
    // }

    const constructItem = ({item}) => {
        return(
            <View style={{ flexDirection: 'row', marginVertical: 2}}>
                <MyAppLabel labelText={item.title} labelStyle={firstScreenStyles.titleStyleBlue}/>
                <MyAppLabel labelText={" - "} labelStyle={firstScreenStyles.titleStyleBlue}/>
                <MyAppLabel labelText={item.id} labelStyle={firstScreenStyles.titleStyleBlue}/>
            </View>
        );
    }

    const constructHeader = ({title}) => {
        return(
            <View style={{ flexDirection: 'row', backgroundColor: '#005566', marginVertical: 2}}>
                <MyAppLabel labelText={title} labelStyle={firstScreenStyles.titleStyle}/>
            </View>
        );
    }

    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column' }}>
                <MyAppLabel labelText={"Scroll n Lists"} labelStyle={firstScreenStyles.titleStyleBlue}/>
                {/* <ScrollView horizontal={false} style={{height:200}} showsVerticalScrollIndicator={false}>
                    <MyAppLabel labelStyle={firstScreenStyles.titleStyleGreen} labelText="React Native provides a number of built-in Core Components ready for you to use in your app. You can find them all in the left sidebar (or menu above, if you are on a narrow screen). If you're not sure where to get started, take a look at the following categories:
                    Basic Components
                    User Interface
                    List Views
                    Android-specific
                    iOS-specific
                    Others
                    You're not limited to the components and APIs bundled with React Native. 
                    React Native has a community of thousands of developers. If you're looking for a 
                    library that does something specific, please refer to this guide about finding libraries
                    Basic Components
                    User Interface
                    List Views
                    Android-specific
                    iOS-specific
                    Others
                    You're not limited to the components and APIs bundled with React Native. 
                    React Native has a community of thousands of developers. If you're looking for a 
                    library that does something specific, please refer to this guide about finding libraries
                    Basic Components
                    User Interface
                    Basic Components
                    User Interface
                    List Views
                    Android-specific
                    iOS-specific
                    Others
                    You're not limited to the components and APIs bundled with React Native. 
                    React Native has a community of thousands of developers. If you're looking for a 
                    library that does something specific, please refer to this guide about finding libraries
                    Basic Components
                    User Interface
                    List Views
                    Android-specific
                    iOS-specific
                    Others
                    You're not limited to the components and APIs bundled with React Native. 
                    React Native has a community of thousands of developers. If you're looking for a 
                    library that does something specific, please refer to this guide about finding libraries
                    Basic Components
                    User Interface
                    List Views
                    Android-specific
                    iOS-specific
                    Others
                    You're not limited to the components and APIs bundled with React Native. 
                    React Native has a community of thousands of developers. If you're looking for a 
                    library that does something specific, please refer to this guide about finding libraries." />
                </ScrollView> */}
                {/* <FlatList 
                data={DATA}
                renderItem={constructItem}/> */}

                <SectionList sections={DATA} 
                renderItem={constructItem}
                renderSectionHeader={constructHeader}/>
            </View>
        </SafeAreaView>
            
    );
};

export default SecondScreen;