import { StyleSheet } from "react-native";

const globalStyles = StyleSheet.create(
    {
        titleStyle: {
            color: '#ffffff', 
            fontSize: 20, 
            fontWeight:'bold', 
            alignSelf: 'center', 
            margin: 20 
        },
        textStyle: {
            color: '#ffffff', 
            fontSize: 20,
            alignSelf: 'center', 
            margin: 10 
        },
        redTextStyle:{
            color: '#C72D0D', 
        },
        imageStyle:{
            width: 100, 
            height: 100, 
            alignSelf: 'center'
        },
        textBoxStyle:{
            margin: 10, 
            paddingHorizontal: 5, 
            borderColor: '#000000', 
            borderWidth: 3, 
            borderRadius: 10, 
            height: 50
        }
    }
);
export default globalStyles;