import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ProfileScreen from '../screens/ProfileScreen';
import ProfileScreen2 from '../screens/ProfileScreen2';

const Stack = createNativeStackNavigator();

const ProfileStack = () => {
    return (
          <Stack.Navigator initialRouteName='Profile' screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Profile" component={ProfileScreen} />
            <Stack.Screen name="Profile2" component={ProfileScreen2} />
          </Stack.Navigator>
      );
}

export default ProfileStack;