import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import SettingsScreen from '../screens/SettingsScreen';
import SettingsScreen2 from '../screens/SettingsScreen2';

const Stack = createNativeStackNavigator();

const SettingsStack = () => {
    return (
          <Stack.Navigator initialRouteName='Settings' screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Settings" component={SettingsScreen} />
            <Stack.Screen name="Settings2" component={SettingsScreen2} />
          </Stack.Navigator>
      );
}

export default SettingsStack;