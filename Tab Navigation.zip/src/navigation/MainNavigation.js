import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import HomeStack from './HomeStack';
import SettingsStack from './SettingsStack';
import ProfileStack from './ProfileStack';

const Tab = createBottomTabNavigator();

const MainNavigation = () => {
    return (
        <NavigationContainer>
          <Tab.Navigator initialRouteName='Home'>
            <Tab.Screen name="Profile" component={ProfileStack} />
            <Tab.Screen name="Home" component={HomeStack} />
            <Tab.Screen name="Settings" component={SettingsStack} />
          </Tab.Navigator>
        </NavigationContainer>
      );
}

export default MainNavigation;