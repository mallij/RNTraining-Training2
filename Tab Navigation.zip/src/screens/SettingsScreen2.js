import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const SettingsScreen2 = (props) => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005500' }}>

                <MyAppLabel labelText={"Settings Screen 2"} labelStyle={firstScreenStyles.titleStyle}/>

            </View>
        </SafeAreaView>
            
    );
};

export default SettingsScreen2;