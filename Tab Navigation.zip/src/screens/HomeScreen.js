import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const HomeScreen = (props) => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"Home Screen"} labelStyle={firstScreenStyles.titleStyle}/>

                <TouchableOpacity onPress={
                    () => { props.navigation.navigate('Home2')}}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', 
                    margin: 10, padding: 20, borderColor: '#000000', 
                    borderWidth: 3, borderRadius: 10 }}>Home 2</Text>
                </TouchableOpacity>

            </View>
        </SafeAreaView>
            
    );
};

export default HomeScreen;