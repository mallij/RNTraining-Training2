import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const HomeScreen2 = (props) => {
    var userName = '';
    console.log('=====> ', props);
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"Home Screen 2"} labelStyle={firstScreenStyles.titleStyle}/>

            </View>
        </SafeAreaView>
            
    );
};

export default HomeScreen2;