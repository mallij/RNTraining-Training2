import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const ProfileScreen2 = (props) => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#000066' }}>

                <MyAppLabel labelText={"Profile Screen 2"} labelStyle={firstScreenStyles.titleStyle}/>

            </View>
        </SafeAreaView>
            
    );
};

export default ProfileScreen2;