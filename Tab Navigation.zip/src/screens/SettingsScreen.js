import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const SettingsScreen = (props) => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005500' }}>

                <MyAppLabel labelText={"Settings Screen"} labelStyle={firstScreenStyles.titleStyle}/>
            
                <TouchableOpacity onPress={
                    () => props.navigation.push('Settings2', {name: 'I am from Settings Screen'})}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', 
                    margin: 10, padding: 20, borderColor: '#000000', 
                    borderWidth: 3, borderRadius: 10 }}>Setting 2</Text>
                </TouchableOpacity>

            </View>
        </SafeAreaView>
            
    );
};

export default SettingsScreen;