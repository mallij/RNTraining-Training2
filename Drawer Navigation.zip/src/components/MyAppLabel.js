import { Text } from 'react-native';
import styles from '../styles/globalStyles';

const MyAppLabel = (props) => {
    return(
        <Text style={props.labelStyle ? props.labelStyle : styles.redTextStyle}> {props.labelText} </Text>
    );
};

export default MyAppLabel;