import React from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const FirstScreen = (props) => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"Navigation Demo"} labelStyle={firstScreenStyles.titleStyle}/>
                
                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your name"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="default"
                    onChangeText={(text) => {userName = text}}
                />

                <TouchableOpacity onPress={
                    () => { props.navigation.navigate('Home',  {name:userName}) }}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', 
                    margin: 10, padding: 20, borderColor: '#000000', 
                    borderWidth: 3, borderRadius: 10 }}>Go To Home</Text>
                </TouchableOpacity>

            </View>
        </SafeAreaView>
            
    );
};

export default FirstScreen;