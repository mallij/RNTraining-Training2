/**
 * @format
 */

import {AppRegistry} from 'react-native';
import FirstScreen from './src/screens/FirstScreen';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => FirstScreen);
