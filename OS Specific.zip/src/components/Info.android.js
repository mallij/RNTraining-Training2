import React from "react";
import { 
    Platform,
    Text, 
    Image
} from 'react-native';

import styles from '../styles/globalStyles';

const imgAndroid = require('../images/android_icon.png');

const Info = () => {
    return(
        <>
            <Text style={styles.androidText}> I am created for Android </Text>
            <Image style={styles.imageStyle} source={imgAndroid}/>
        </>
    );
};

export default Info;