import React from "react";
import { 
    Platform,
    Text, 
    Image
} from 'react-native';

import styles from '../styles/globalStyles';

const imgiOS = require('../images/apple_icon.png');

const Info = () => {
    return(
        <>
            <Text style={styles.iosText}> I am created for iOS/Apple </Text>
            <Image style={styles.imageStyle} source={imgiOS}/>
        </>
    );
};

export default Info;