import React, { useState } from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from './styles/globalStyles';
import MyAppLabel from './components/MyAppLabel';

const imagePath = require('./images/RN_Android_iOS.png');

const StateManagement = () => {
    // var userName = '', age = 0;
    const [userName, setUserName] = useState('');
    const [age, setAge] = useState(0);

    const verifyInfo = () =>{
        if(age < 18)
        console.log('Hello, ', userName+' you are not eligible to cast your vote');
        else
        console.log('Hello, ', userName+' you are eligible to cast your vote, be wise');
    }

    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"React Native State"} labelStyle={firstScreenStyles.titleStyle}/>
                
                <Text style={[firstScreenStyles.textStyle, firstScreenStyles.redTextStyle,]}> I know what is the purpose of SafeAreaView </Text>
                
                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your name"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="default"
                    onChangeText={(text) => {setUserName(text)}}
                />

                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your age"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="number-pad"
                    onChangeText={(text) => {setAge(text)}}
                />

                <TouchableOpacity onPress={
                    () => verifyInfo()}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', margin: 10, padding: 20, borderColor: '#000000', borderWidth: 3, borderRadius: 10 }}>Verify</Text>
                </TouchableOpacity>

                <Text style={(age < 18) ? firstScreenStyles.redTextStyle : firstScreenStyles.textStyle}> {(age < 18) ? 'Hello, '+ userName+' you are not eligible to cast your vote' : 'Hello, ' + userName+' you are eligible to cast your vote, be wise'} </Text>
            </View>
        </SafeAreaView>
    );
};

export default StateManagement;