import React, { Component } from "react";
import { 
    View, 
    SafeAreaView, Pressable,
    Text, Image, TextInput, Button, StyleSheet,
    TouchableOpacity, TouchableHighlight, TouchableWithoutFeedback } from 'react-native';

import firstScreenStyles from './styles/globalStyles';
import MyAppLabel from './components/MyAppLabel';

const imagePath = require('./images/RN_Android_iOS.png');

class FirstScreenClass extends Component
{
    constructor()
    {
        super();
    }

    render(){
        var userName = '';
        return(
            <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                {/* <Text style={firstScreenStyles.titleStyle}> My First RN App </Text> */}
                <MyAppLabel labelText={"My First RN App"} labelStyle={firstScreenStyles.titleStyle}/>
                
                <Text style={[firstScreenStyles.textStyle, firstScreenStyles.redTextStyle,]}> I know what is the purpose of SafeAreaView </Text>
                {/* <Text style={firstScreenStyles.textStyle}> I have also started using View and Text Components </Text>
                <Text style={firstScreenStyles.textStyle}> I have also Wrote code for Button Events </Text> */}

                <MyAppLabel labelText={'I have also started using View and Text Components'} labelStyle={firstScreenStyles.textStyle}/>

                <MyAppLabel labelText={'I have also Wrote code for Button Events'}/>

                <Image style={firstScreenStyles.imageStyle} source={imagePath}/>

                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your name"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="default"
                    onChangeText={(text) => {userName = text}}
                />

                <Button
                title="Say Hi"
                color={'#000000'}
                onPress={() => { console.log('From Button : Hi, ', userName)}} />

                <TouchableOpacity onPress={
                    () => console.log('From Opacity : Hi, ', userName)}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', margin: 10, padding: 20, borderColor: '#000000', borderWidth: 3, borderRadius: 10 }}>Opacity Button</Text>
                </TouchableOpacity>

                <TouchableHighlight onPress={
                    () => console.log('From Highlight : Hi, ', userName)}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', margin: 10, padding: 20, borderColor: '#000000', borderWidth: 3, borderRadius: 10 }}>Hilight Button</Text>
                </TouchableHighlight>

                <TouchableWithoutFeedback onPress={
                    () => console.log('From Wihout Feedback : Hi, ', userName)}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', margin: 10, padding: 20, borderColor: '#000000', borderWidth: 3, borderRadius: 10 }}>Without FeedBack Button</Text>
                </TouchableWithoutFeedback>

                <Pressable 
                    style={{ alignSelf:'center'}}
                    onPressIn={() => console.log('Pressed In ')}
                    onPressOut={() => console.log('Pressed Out ')}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', margin: 10, padding: 20, borderColor: '#000000', borderWidth: 3, borderRadius: 10 }}>I am Pressable</Text>
                </Pressable>

            </View>
        </SafeAreaView>
        );
    }
}

export default FirstScreenClass;