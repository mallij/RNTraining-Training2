import React from "react";
import { 
    View, 
    SafeAreaView, Platform,
    Text, Image
} from 'react-native';

import styles from '../styles/globalStyles';
import Info from '../components/Info';
const imgAndroid = require('../images/android_icon.png');
const imgiOS = require('../images/apple_icon.png');


const FirstScreen = () => {
    var userName = '';
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column'}}>

            <Text style={styles.titleStyleBlue}> Platform Specific Implementation </Text>
            <Info />
                
            </View>
        </SafeAreaView>
            
    );
};

// const firstScreenStyles = StyleSheet.create(
//     {
//         titleStyle: {
//             color: '#ffffff', 
//             fontSize: 20, 
//             fontWeight:'bold', 
//             alignSelf: 'center', 
//             margin: 20 
//         },
//         textStyle: {
//             color: '#ffffff', 
//             fontSize: 20,
//             alignSelf: 'center', 
//             margin: 10 
//         },
//         redTextStyle:{
//             color: '#C72D0D', 
//         },
//         imageStyle:{
//             width: 100, 
//             height: 100, 
//             alignSelf: 'center'
//         },
//         textBoxStyle:{
//             margin: 10, 
//             paddingHorizontal: 5, 
//             borderColor: '#000000', 
//             borderWidth: 3, 
//             borderRadius: 10, 
//             height: 50
//         }
//     }
// );

export default FirstScreen;