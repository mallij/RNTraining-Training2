import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// For Redux configuration
import { createStore, combineReducers } from 'redux';
import { Provider } from 'react-redux';

import userDetailsReducer from './reducers/userDetailsReducer';
import productReducer from './reducers/productReducer';

import FirstScreen from './screens/FirstScreen';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';
import SettingsScreen from './screens/SettingsScreen';

// const reducers = combineReducers({user: userDetailsReducer, product: productReducer});
// const appStore = createStore(reducers);

const appStore = createStore(userDetailsReducer);

const Stack = createNativeStackNavigator();

const Navigation = () => {
    return (
      <Provider store={appStore}>
        <NavigationContainer>
          <Stack.Navigator initialRouteName='First'>
            <Stack.Screen name="First" component={FirstScreen}/>
            <Stack.Screen name="Profile" component={ProfileScreen} />
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Settings" component={SettingsScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </Provider>
      );
}

export default Navigation;