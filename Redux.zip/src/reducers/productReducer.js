import { CHANGE_PRODUCT_COUNT } from '../constants/constants';
const initialState = {
    products : 19
};

const productReducer = (state = initialState, action) => {
    switch(action.type) {
        case CHANGE_PRODUCT_COUNT:
        return {
        ...state,
        products: action.payload.productCount
    };
    default:
        return state;
    }
}
export default productReducer;