import { CHANGE_USER_DETAILS } from '../constants/constants';
const initialState = {
    age: 0,
    name: ''
};

const userDetailsReducer = (state = initialState, action) => {
    switch(action.type) {
        case CHANGE_USER_DETAILS:
        return {
        ...state,
        age: action.payload.age,
        name: action.payload.name
    };
    default:
        return state;
    }
}
export default userDetailsReducer;