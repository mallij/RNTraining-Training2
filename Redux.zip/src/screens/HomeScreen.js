import React from "react";
import { useSelector } from "react-redux";
import { 
    View, 
    SafeAreaView,
    Text,
    TouchableOpacity } from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';

const HomeScreen = (props) => {
    const reduxState = useSelector((state) => state);
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"Home Screen"} labelStyle={firstScreenStyles.titleStyle}/>
                <TouchableOpacity onPress={
                    () => { props.navigation.navigate('Profile')}}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', 
                    margin: 10, padding: 20, borderColor: '#000000', 
                    borderWidth: 3, borderRadius: 10 }}>Go To Profile</Text>
                </TouchableOpacity>

                <MyAppLabel labelText={reduxState.name} labelStyle={firstScreenStyles.titleStyle}/>

                <MyAppLabel labelText={reduxState.age} labelStyle={firstScreenStyles.titleStyle}/>
            </View>
        </SafeAreaView>
            
    );
};

export default HomeScreen;