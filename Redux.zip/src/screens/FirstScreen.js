import React from "react";
import { useDispatch } from "react-redux";
import { 
    View, 
    SafeAreaView,
    Text, TextInput,
    TouchableOpacity
} from 'react-native';

import firstScreenStyles from '../styles/globalStyles';
import MyAppLabel from '../components/MyAppLabel';
import { CHANGE_USER_DETAILS } from '../constants/constants';

const FirstScreen = (props) => {
    const dispatch = useDispatch();
    var userName = '', userAge = 0;
    return(
        <SafeAreaView>
            <View style={{ flexDirection: 'column', backgroundColor: '#005566' }}>

                <MyAppLabel labelText={"Navigation Demo"} labelStyle={firstScreenStyles.titleStyle}/>
                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your name"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="default"
                    onChangeText={(text) => {userName = text}}
                />

                <TextInput 
                    style={firstScreenStyles.textBoxStyle}
                    placeholder="Enter your age"
                    placeholderTextColor={'#ffffff'}
                    keyboardType="number-pad"
                    onChangeText={(text) => {userAge = text}}
                />

                <TouchableOpacity onPress={
                    () => { 
                        const action = {
                            type: CHANGE_USER_DETAILS,
                            payload: {
                                name: userName,
                                age: userAge
                            }
                        };
                        dispatch(action);
                        props.navigation.navigate('Home');
                    }}>
                    <Text style={{ fontSize: 20, alignSelf: 'center', 
                    margin: 10, padding: 20, borderColor: '#000000', 
                    borderWidth: 3, borderRadius: 10 }}>Go To Home</Text>
                </TouchableOpacity>

            </View>
        </SafeAreaView>
            
    );
};

export default FirstScreen;